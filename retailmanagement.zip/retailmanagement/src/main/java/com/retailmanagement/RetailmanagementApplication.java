package com.retailmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetailmanagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(RetailmanagementApplication.class, args);
        System.out.println("running...");
    }

}
