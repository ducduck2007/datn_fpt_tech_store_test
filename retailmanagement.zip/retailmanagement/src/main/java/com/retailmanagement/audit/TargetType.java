package com.retailmanagement.audit;

public enum TargetType {
    USER,
    PRODUCT,
    CUSTOMER,
    ORDER
}
