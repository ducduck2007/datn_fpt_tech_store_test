package com.retailmanagement.audit;

public enum AuditModule {
    USER,
    PRODUCT,
    CUSTOMER,
    ORDER
}
