package com.retailmanagement.audit;

public enum AuditAction {
    CREATE,
    UPDATE,
    CHANGE_ROLE,
    CHANGE_PASSWORD,
    DELETE,
    LOGIN,
    LOGOUT
}
