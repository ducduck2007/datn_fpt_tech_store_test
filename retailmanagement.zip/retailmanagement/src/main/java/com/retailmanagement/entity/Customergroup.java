package com.retailmanagement.entity;

public class Customergroup {
}
