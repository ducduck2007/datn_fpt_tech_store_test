package com.retailmanagement.entity;

public enum Role {
    ADMIN, SALES, INVENTORY, CUSTOMER
}
