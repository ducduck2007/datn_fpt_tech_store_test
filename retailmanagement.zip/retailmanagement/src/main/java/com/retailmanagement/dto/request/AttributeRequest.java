package com.retailmanagement.dto.request;

import lombok.Data;

@Data
public class AttributeRequest {
    private String name;
    private String value;
}