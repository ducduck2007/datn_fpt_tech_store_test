package com.retailmanagement.dto.response;

public record ModuleLogReportResponse(
        String module,
        Long total
) {
}
