package com.retailmanagement.dto.request;

public class SetDefaultCurrencyRequest {
    private String currencyCode;

    public String getCurrencyCode() { return currencyCode; }
    public void setCurrencyCode(String currencyCode) { this.currencyCode = currencyCode; }
}
